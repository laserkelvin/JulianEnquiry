// app.js
document.addEventListener("DOMContentLoaded", () => {
	// on DOM ready
});